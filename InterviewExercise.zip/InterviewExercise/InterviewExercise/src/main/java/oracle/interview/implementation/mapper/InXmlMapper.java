package oracle.interview.implementation.mapper;

import java.time.Instant;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import oracle.interview.metrics.TargetMetricsContainer;
import oracle.interview.implementation.utils.EnumConstants;

public class InXmlMapper {

	public TargetMetricsContainer inXmlToTargetMetricsContainer(NodeList nList, int line) {
		TargetMetricsContainer targetMetricsContainer = null;
		Node nNode = nList.item(line);

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

			targetMetricsContainer = new TargetMetricsContainer(
					eElement.getElementsByTagName(EnumConstants.NAME.getValue()).item(0).getTextContent(),
					eElement.getElementsByTagName(EnumConstants.TYPE.getValue()).item(0).getTextContent());

			NodeList nListMetrics = eElement.getElementsByTagName(EnumConstants.METRICS.getValue());

			for (int tempmetrics = 0; tempmetrics < nListMetrics.getLength(); tempmetrics++) {
				Node nNodeMetrics = nListMetrics.item(tempmetrics);
				if (nNodeMetrics.getNodeType() == Node.ELEMENT_NODE) {
					Element eElementmetrics = (Element) nNodeMetrics;
					targetMetricsContainer.addMetric(
							eElementmetrics.getElementsByTagName(EnumConstants.NAME.getValue()).item(0)
									.getTextContent(),
							Instant.parse(eElementmetrics.getElementsByTagName(EnumConstants.TIMESTAMP.getValue())
									.item(0).getTextContent()),
							Integer.parseInt((eElementmetrics.getElementsByTagName(EnumConstants.VALUE.getValue())
									.item(0).getTextContent())));
				}
			}

		}
		return targetMetricsContainer;
	}

}
