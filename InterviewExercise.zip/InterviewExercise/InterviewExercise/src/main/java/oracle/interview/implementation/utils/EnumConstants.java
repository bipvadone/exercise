package oracle.interview.implementation.utils;

public enum EnumConstants {
	
	NAME("name"),TYPE("type"),TARGET("target"),METRICS("metrics"),TIMESTAMP("timestamp"),VALUE("value");
	
	
	private String value;

	private EnumConstants(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	

}
