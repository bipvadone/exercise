package oracle.interview.metrics;

public interface MetricWriter {

    void writeMetricsContainer(TargetMetricsContainer metricsContainer);

}
