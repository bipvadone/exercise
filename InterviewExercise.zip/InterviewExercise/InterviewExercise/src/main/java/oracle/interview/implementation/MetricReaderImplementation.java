package oracle.interview.implementation;

import oracle.interview.metrics.MetricReader;
import oracle.interview.metrics.TargetMetricsContainer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import oracle.interview.implementation.mapper.InXmlMapper;
import oracle.interview.implementation.utils.EnumConstants;

import org.xml.sax.SAXException;

public class MetricReaderImplementation implements MetricReader {
	@Override
	public List<TargetMetricsContainer> readMetrics(InputStream metricInputStream)
			throws ParserConfigurationException, SAXException, IOException {
		// TODO: implement this, reading data from the input stream, returning a list of
		// containers read from the stream..

		List<TargetMetricsContainer> listTargretMetricsContainer = new ArrayList<>();

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = (Document) dBuilder.parse(metricInputStream);

		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName(EnumConstants.TARGET.getValue());

		for (int line = 0; line < nList.getLength(); line++) {  
			listTargretMetricsContainer.add(new InXmlMapper().inXmlToTargetMetricsContainer(nList, line));
		}

		return listTargretMetricsContainer;
	}

}
