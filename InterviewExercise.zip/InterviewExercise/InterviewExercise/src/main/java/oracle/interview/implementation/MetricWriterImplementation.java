package oracle.interview.implementation;

import java.sql.SQLException;

import oracle.interview.metrics.MetricStorage;
import oracle.interview.metrics.MetricWriter;
import oracle.interview.metrics.TargetMetricsContainer;

public class MetricWriterImplementation implements MetricWriter {

    private final MetricStorage storage;

    public MetricWriterImplementation(MetricStorage storage) {
        this.storage = storage;
    } 
    
    
    @Override
    public void writeMetricsContainer(TargetMetricsContainer metricsContainer) {
        // TODO: write this metricsContainer to the MetricStorage. Hint
        //      storage.write(metricsContainer);
        //  partially works.  Since the write could fail, retry the write on failure
        //  as appropriate.
    	boolean wrote=true;
    	

		System.out.println("-----------MetricWriterImplementation-----------------");
		try {
			storage.write(metricsContainer);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			System.out.println("getMessage:::::::::::::::::: "+e.getMessage());
			System.out.println("getSQLState::::::::::::::::: "+e.getSQLState());
			System.out.println("getErrorCode:::::::::::::::: "+e.getErrorCode());
			System.out.println("getCause:::::::::::::::::::: "+e.getCause());
			System.out.println("getNextException:::::::::::: "+e.getNextException());  
			wrote=false;
	 
			storage.close();
		} catch (Exception ex) { 
            ex.printStackTrace();
        } finally {
 
             if(wrote)
             {
            	 System.out.println("The metric "+metricsContainer.getTargetName()+ " was wrote succesfully"); 
             }else
             {
            	 System.out.println("The metric "+metricsContainer.getTargetName()+" was not wrote succesfully");
             }
             
        }
 
		System.out.println("-----------MetricWriterImplementation-----------------");
 
    }
    
   
}
